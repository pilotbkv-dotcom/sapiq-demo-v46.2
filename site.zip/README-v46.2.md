# Sapiq v46.2 — release notes

This is a static, offline demonstration for GitHub Pages, not a live trading integration.

Changes versus v46.1:
- Removed overlapping miniature PnL card stack in the hero while retaining the 3-format gallery below.
- Rebuilt the sample calculator breakdown: Polymarket share price, share quantity, share purchase total, sportsbook stake and total capital.
- Preserved entered sportsbook stake when displayed odds change; result is the worse of the two exclusive outcome payouts.
- Added a scannable QR to exported PnL PNG in landscape, square and story, with original mascot and Verified Builder badge.
- Localized pricing headlines and mini-calculator labels, refined assistant conversation in RU/EN/ES/ZH, updated social icons and short dashes.
- Normalized language-scoped terminal navigation to prevent /ru/ru/terminal paths.
- Changed PWA cache version and pre-cached new CSS/JS.

Deployment: use the two-file kit: upload site.zip in repository root and put pages.yml at .github/workflows/pages.yml. Settings -> Pages -> GitHub Actions.

Demo login: demo / sapiq-demo. This is client-only authentication, not production security.
